# 1.0.0

- Simple volume control

# 1.0.2

- removed unnecessary BMX Lobby Compatibility mod (Actually this time)

# 1.0.1

- removed unnecessary BMX Lobby Compatibility mod

# 1.0.0

- Simple volume control

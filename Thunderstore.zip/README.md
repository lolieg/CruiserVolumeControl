# Features

- LethalConfig entry to change the volume of the Cruiser's radio. (no restart
  required)
- Maybe more later. Who knows!
